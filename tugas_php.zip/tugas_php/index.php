<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Layout Modern dengan Header, Sidebar, Konten, dan Footer</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #e9ecef;
        }
        .container {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .header {
            background-color: #bcdee7;
            color: #333;
            text-align: center;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            font-family: 'Poppins';
        }
        .content-area {
            display: flex;
            flex: 1;
            margin: 20px;
        }
        .sidebar {
            flex: 1;
            background-color: #343a40;
            color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .sidebar h2 {
            border-bottom: 2px solid #495057;
            padding-bottom: 10px;
            margin-bottom: 20px;
            font-size: 1.2em;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar ul li {
            margin: 15px 0;
        }
        .sidebar ul li a {
            color: #adb5bd;
            text-decoration: none;
            padding: 10px;
            display: flex;
            align-items: center;
            background-color: #495057;
            border-radius: 5px;
            transition: 0.3s ease;
        }
        .sidebar ul li a i {
            margin-right: 12px;
            font-size: 1.2em;
        }
        .sidebar ul li a:hover {
            background-color: #6c757d;
            color: white;
        }
        .content {
            flex: 3;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .footer {
            background-color: #bcdee7;
            color: #111810;
            text-align: center;
            padding: 15px;
            box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.1);
        }
        @media (max-width: 768px) {
            .content-area {
                flex-direction: column;
                margin: 10px;
            }
            .sidebar {
                order: 2;
                margin-bottom: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Kayy Archive</h1>
        </div>
        <div class="content-area">
            <div class="sidebar">
                <h2>Menu </h2>
                <ul>
                    <li><a href="profile.php"><i class="fas fa-user"></i> My Profile</a></li>
                    <li><a href="#dashboard"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                    <li><a href="#settings"><i class="fas fa-cog"></i> Pengaturan</a></li>
                    <li><a href="#logout"><i class="fas fa-sign-out-alt"></i> Keluar</a></li>
                </ul>
            </div>
            <div class="content">
            </div>
        </div>
        <div class="footer">
            <p>Kayywebsite &copy</p>
        </div>
    </div>
</body>
</html>

