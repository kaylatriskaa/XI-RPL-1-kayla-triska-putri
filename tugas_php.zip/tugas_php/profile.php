<?php
    // Data profil dalam bentuk array
    $profil = [
        "nama" => "Kayla Triska Putri",   
        "umur" => "15 tahun",         
        "sekolah" => "SMKN 2 Bandung",    
        "kelas" => "XI RPL 1",
        "cita-cita"=> "Cita-cita saya adalah saya ingin menjadi pengusaha, menjadi orang baik, orang sukses,orang jujur dan selalu berada di jalan Allah",
    ];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <title>My Profile</title>
    <style>

@import url('https://fonts.googleapis.com/css?family=Montserrat');
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #bcdee7 ;
            margin: 0;
            padding: 70px;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background: #ffff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1{
            color: #333;
            text-align: center;
            border-bottom: 2px solid #333;
        }
        p {
            color: #111810;
        }
        .social-icons {
            display: flex;
            margin-top: 20px;
            justify-content: center;
        }

        .social-icons a {
            color: #333;
            text-decoration: none;
            font-size: 40px;
            margin: 0 10px;
            transition: color 0.4s ease, transform 0.4s ease;
        }

        .social-icons a:hover {
            transform: scale(1.2); /* Membesarkan ikon saat dihover */
        }

        .social-icons .instagram:hover {
            color: #E1306C; /* Warna khas Instagram */
        }

        .social-icons .tiktok:hover {
            color: #red; /* Warna khas TikTok */
        }

        .social-icons .whatsapp:hover {
            color: #25D366; /* Warna khas WhatsApp */
        }



        
    </style>
</head>
<body>
    <div class="container">
    <a href="index.php" target="_blank" class="instagram"><i class="fas fa-home"></i></a>
    <h1>My Profile</h1>
        <p><strong>Nama     :</strong> <?php echo $profil['nama']; ?></p>
        <p><strong>Umur     :</strong> <?php echo $profil['umur']; ?></p>
        <p><strong>Sekolah :</strong> <?php echo $profil['sekolah']; ?></p>
        <p><strong>Kelas :</strong> <?php echo $profil['kelas']; ?></p>
        <p><strong>Cita-cita :</strong> <?php echo $profil['cita-cita']; ?></p>
        <div class="social-icons">
            <a href="https://www.instagram.com/trkylas" target="_blank" class="instagram"><i class="fab fa-instagram"></i></a>
            <a href="https://www.tiktok.com/@yourtiktokusername" target="_blank" class="tiktok"><i class="fab fa-tiktok"></i></a>
            <a href="https://wa.me/yourphonenumber" target="_blank" class="whatsapp"><i class="fab fa-whatsapp"></i></a>
        </div>
</body>
</html>
