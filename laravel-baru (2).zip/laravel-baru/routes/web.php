<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/registrasi', [AuthController::class, 'TampilRegistrasi'])->name('registrasi.tampil');
Route::post('/registrasi/submit', [AuthController::class, 'SubmitRegistrasi'])->name('registrasi.submit');

Route::get('/login', [AuthController::class, 'TampilLogin'])->name('login.tampil');
Route::post('/login/submit', [AuthController::class, 'SubmitLogin'])->name('login.submit');
//route resource for products
Route::resource('/products', \App\Http\Controllers\ProductController::class);

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
