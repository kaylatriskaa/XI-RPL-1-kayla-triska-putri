<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class AuthCntroller extends Controller
{
    function TampilRegistrasi() {
        return view('registrasi');
    }
    function SubmitRegistrasi(Request $request)  {
      $user = new User();
      $user->name = $request->name;
      $user->email = $request->email;
      $user->password = bcrypt($request->password);
      $user->save();
      //dd($user);
     // return redirect()->route('login');

      function TampilLogin(){
        return view('login.tampil');
      }
    }
}
